import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common.service';
import { Post } from '../post';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
user
posts
temp
title:String="BUY N SELL @CAPGEMINI"

  valbutton="Save"
  registeredData
// email
  constructor(private newservice:CommonService,private router:Router) { }
  post:Post=new Post()
  ngOnInit() {
    this.newservice.GetUser().subscribe((data) => this.registeredData = data)
this.user=localStorage.getItem(this.newservice.usn)
alert("from post component"+this.user)
// for(let e of this.registeredData){
//   if(this.user=e.username){
//     this.email=e.email
//   }
// }
// alert("eamil: "+this.email)
// this.email=this.newservice.getEmail()
// alert("from post component"+this.email)
}
  addPost(posts){
   
    if(!this.post.postName || !this.post.postPrice || !this.post.postDes || !this.post.image || !this.post.email || !this.post.contact || !this.post.category){
    
      return (this.temp=1,alert("All fields are required!!!!!!!"))
    }
    else{
      posts.mode=this.valbutton
      this.temp=2
      this.newservice.addPost(posts).subscribe(data=>{alert(data.data)})
      // this.router.navigate(["showposts"])
  this.newservice.GetPosts().subscribe((data) => this.posts = data)
  // this.router.navigate(['signin'])
      // alert(this.post.category)
    }
    this.post=new Post()
  }
  loginClick(){
    this.router.navigate(['login'])
    }
    homeClick(){
      this.router.navigate(['signin'])
    }
    logoutClick(){
      // this.isUserLoggedIn=false;
    this.router.navigate([''])
    localStorage.removeItem(this.newservice.usn)
    // alert("service"+this.newservice.usn)
    this.user=localStorage.getItem(this.newservice.usn)
    // alert("component"+this.usn2)
    }

}
