import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { Post } from '../post';

@Component({
  selector: 'app-logged-in',
  templateUrl: './logged-in.component.html',
  styleUrls: ['./logged-in.component.css'],
})
export class LoggedInComponent implements OnInit {

  constructor( private newservice:CommonService,private router:Router) { }
  flag:boolean=false;
  valbutton="Save"
post:Post=new Post()
// temp
posts
usn2:string
// id
  ngOnInit() {
    this.usn2=localStorage.getItem(this.newservice.usn)
    this.
    newservice.GetPosts().subscribe((data) => this.posts = data)

  // alert("component"+this.usn2)
  // this.newservice.increase()
  // alert(this.temp)
  // alert("service"+this.newservice.temp)

    }
  // isUserLoggedIn=true;
title:String="BUY N SELL @CAPGEMINI"
addPostClick(){
  // this.ngOnInit()
  this.router.navigate(['post'])
}
logoutClick(){
  // this.isUserLoggedIn=false;
this.router.navigate([''])
localStorage.removeItem(this.newservice.usn)
// alert("service"+this.newservice.usn)
this.usn2=localStorage.getItem(this.newservice.usn)
// alert("component"+this.usn2)
}
loginClick(){
this.router.navigate(['login'])

}
// descriptionClick(id){
//   // this.id=id
//   // alert(id)
//   // this.newservice.getDescription(id).subscribe(data=>{alert(data.data)})
//   // this.newservice.getdescription(id)
//   this.router.navigate(['description'])
// }
deletePost(id){
  alert(id)
  this.newservice.deletePost(id).subscribe(data=>{
    alert(data.data);this.ngOnInit()
  }
  )
}
EditClick(p){
  this.flag=true;
this.post.id=p._id;
this.post.postName=p.postName
this.post.postPrice=p.postPrice
this.post.postDes=p.postDes
this.post.category=p.category
}
addPost(posts){
  this.valbutton="Update"
  posts.mode=this.valbutton
  this.newservice.addPost(posts).subscribe(data=>{alert(data.data)})
  // this.router.navigate(["showposts"])
this.newservice.GetPosts().subscribe((data) => this.posts = data)
this.ngOnInit()
this.flag=false;
// this.router.navigate(['signin'])
  alert(this.post.category)
}
}
