export class User {
    name:string
    address:string
}

